package com.carrito.compras.jobbatchcarritocompras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobBatchCarritoComprasApplicationTests {

	@Test
	void contextLoads() {
	}

}
